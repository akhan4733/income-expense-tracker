package org.khan.incomegui;

//all imports being used for this panel
import org.khan.bank.Expense;
import org.khan.bank.Income;
import org.khan.bank.Transaction;
import org.khan.database.Database;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

//variables are being stated
public class IncomePanel extends JPanel {
    private JPanel labelsAndTextFieldsPanel;  //used on panel
    private JPanel labelAndTextField1; //used on panel
    private JPanel labelAndTextField2; //used on panel
    private JPanel labelAndTextField3; //used on panel
    private JPanel buttonPanel; //button panel
    private JLabel dateLabel; //making a date label
    private JLabel descriptionLabel; //making a description label
    private JLabel amountLabel; //making an account label

    private JLabel balanceLabel; //making a balance label

    private JButton addButton; // adding a button


    //all three are for the income array being used
    private JTextField dateTextField; //
    private JTextField descriptionTextField;
    private JTextField amountTextField;

    private JTable table; //table to store everything

    //setting the size and where everything goes
    public IncomePanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(800, 600));//size
        setMaximumSize(new Dimension(800, 600)); //size

        labelsAndTextFieldsPanel = new JPanel();
        labelAndTextField1 = new JPanel();
        labelAndTextField2 = new JPanel();
        labelAndTextField3 = new JPanel();
        buttonPanel= new JPanel();

        //all the background colors.
        labelsAndTextFieldsPanel.setBackground(new Color(96,57,28));
        labelAndTextField1.setBackground(new Color(96,57,28));
        labelAndTextField2.setBackground(new Color(96,57,28));
        labelAndTextField3.setBackground(new Color(96,57,28));
        buttonPanel.setBackground(new Color(96,57,28));


        //setting layout
        labelsAndTextFieldsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
        labelAndTextField1.setLayout(new BoxLayout(labelAndTextField1, BoxLayout.Y_AXIS));
        labelAndTextField2.setLayout(new BoxLayout(labelAndTextField2, BoxLayout.Y_AXIS));
        labelAndTextField3.setLayout(new BoxLayout(labelAndTextField3, BoxLayout.Y_AXIS));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));



        String[] columnNames = {"Date", "Description", "Amount"}; //three text fields
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        //made a table to store all the information in
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);
        table.setDefaultEditor(Object.class, null);
        TableCellRenderer renderer = table.getTableHeader().getDefaultRenderer();
        JLabel label = (JLabel) renderer;
        label.setHorizontalAlignment(JLabel.CENTER);


        initLabels();
        initTextFields();
        initButtons();


        labelAndTextField1.add(dateLabel);
        labelAndTextField1.add(dateTextField);

        labelAndTextField2.add(descriptionLabel);
        labelAndTextField2.add(descriptionTextField);

        labelAndTextField3.add(amountLabel);
        labelAndTextField3.add(amountTextField);

        labelsAndTextFieldsPanel.add(labelAndTextField1);
        labelsAndTextFieldsPanel.add(labelAndTextField2);
        labelsAndTextFieldsPanel.add(labelAndTextField3);

        buttonPanel.add(addButton);
        buttonPanel.add(balanceLabel);

        add(scrollPane);
        add(labelsAndTextFieldsPanel);
        add(buttonPanel);

        loadAccountTransactions();
    }

    //classifying the labels: "date, description, amount, and balance" with setting the placement, color, and size.
    private void initLabels() {
        dateLabel = new JLabel("date");
        descriptionLabel = new JLabel("description");
        amountLabel = new JLabel("amount");
        balanceLabel = new JLabel("Balance: ");

        dateLabel.setPreferredSize(new Dimension(250, 50));
        descriptionLabel.setPreferredSize(new Dimension(250,50));
        amountLabel.setPreferredSize(new Dimension(250,50));

        dateLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        descriptionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        amountLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        dateLabel.setForeground(Color.WHITE);
        descriptionLabel.setForeground(Color.WHITE);
        amountLabel.setForeground(Color.WHITE);

        dateLabel.setBackground(new Color(96,57,28));
    }

    //classifying the text fields with where it needs to be placed and how it needs to be set
    private void initTextFields() {
        dateTextField = new JTextField();
        descriptionTextField = new JTextField();
        amountTextField = new JTextField();

        dateTextField.setPreferredSize(new Dimension(250,50));
        descriptionTextField.setPreferredSize(new Dimension(250,50));
        amountTextField.setPreferredSize(new Dimension(250,50));

        dateTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        descriptionTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        amountTextField.setAlignmentX(Component.CENTER_ALIGNMENT);

    }
// loading transaction from the database
    private void loadAccountTransactions() {
        ArrayList<Transaction> ts = Database.getAllTransactionsForAccount();

        for(var t : ts) {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.addRow(new Object[] {
                    t.getDate(),
                    t.getDescription(),
                    t.getAmount()
            });
        }
        double total = ts
                .stream()
                .mapToDouble(Transaction::getAmount)
                .sum();

        NumberFormat numberFormat = NumberFormat.getCurrencyInstance();
        balanceLabel.setText("Balance: " + numberFormat.format(total));
    }

    //add button with the background for the button
     private void initButtons(){
        addButton = new JButton("Add");
        addButton.setBackground(Color.WHITE);
        addButton.setForeground(Color.BLACK);
        addButton.setBorderPainted(false);
        addButton.setOpaque(true);
        addButton.setFocusPainted(false);


        //checks the year to see if it acceptable to use
        addButton.addActionListener(e -> {
            Transaction transaction;
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); //only in this format
            if(Double.parseDouble(amountTextField.getText()) >= 0) {
                transaction = new Income(
                        Double.parseDouble(amountTextField.getText()),
                        descriptionTextField.getText(),
                        LocalDate.parse(dateTextField.getText(), dateTimeFormatter),
                        Database.loggedInAccount
                );
            }
            //make a new expense
            else {
                transaction = new Expense(
                        Double.parseDouble(amountTextField.getText()),
                        descriptionTextField.getText(),
                        LocalDate.parse(dateTextField.getText(), dateTimeFormatter),
                        Database.loggedInAccount
                );
            }

            //adds new rows in this table when user adds a new income or expense
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.addRow(new Object[] {
                    dateTextField.getText(),
                    descriptionTextField.getText(),
                    amountTextField.getText()
            });
            Database.addTransactionToDatabase(transaction);

            double total = Database
                    .getAllTransactionsForAccount()
                    .stream()
                    .mapToDouble(Transaction::getAmount)
                    .sum();

            NumberFormat numberFormat = NumberFormat.getCurrencyInstance();
            balanceLabel.setText("Balance: " + numberFormat.format(total)); //sets and calculates the balance
        });
     }
}
