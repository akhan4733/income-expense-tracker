package org.khan.incomegui;

import javax.swing.*;

//frame being used for the panel
public class IncomeFrame extends JFrame {
    private IncomePanel incomePanel;
    public IncomeFrame() {
        incomePanel = new IncomePanel();
        add(incomePanel);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Income Frame");
    }
}
