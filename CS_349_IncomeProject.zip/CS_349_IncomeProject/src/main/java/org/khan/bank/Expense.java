package org.khan.bank;

import java.time.LocalDate;

//showing all the variables used that extend to the transaction class
public class Expense extends Transaction {

    //declaring the variables being used
    public Expense(double amount, String description, LocalDate date, String aName) {
        super(amount, description, date, 'N', aName);
    }
    public Expense(double amount, String description, LocalDate date, int id, String aName) {
        super(amount, description, date, 'N', id, aName);
    }
}
