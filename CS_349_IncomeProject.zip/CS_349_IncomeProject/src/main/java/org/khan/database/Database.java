package org.khan.database;

import org.khan.bank.Expense;
import org.khan.bank.Income;
import org.khan.bank.Transaction;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;


//connection is being set and classified.
public class Database {
    private static Connection connection;
    public static String loggedInAccount;

    public static void startDatabase() {
        try {
            connection = DriverManager.getConnection(//into the database that i created
                    "jdbc:mysql://localhost:3306/incomeproject", "root", "Aamnakhan786");
        } catch (SQLException e) {//catches any exceptions being thrown.
            e.printStackTrace();
        }
    }

//try the connection and if there is an error than throw an exception
    public static void closeDatabase() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //add all the new accounts made from the sign in sheet
    public static void addAccountToDatabase(String accountEmail, String accountName, String accountPassword) {
        try {
            Statement statement = connection.createStatement();
            String addAccountToDatabaseStatement =
                    String.format("INSERT INTO Account VALUES('%s', '%s', '%s');", accountName, accountPassword, accountEmail);
            statement.executeUpdate(addAccountToDatabaseStatement);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //see if an account exists in the database. if no, then user has to make a new account.
    public static boolean checkIfAccountExists(String accountEmail, String accountName, String accountPassword) {
        try {
            Statement statement = connection.createStatement();
            String accountExistsStatement =
                    String.format("SELECT * FROM Account WHERE accountName = '%s' AND accountPassword = '%s' AND accountEmail = '%s';",
                            accountName, accountPassword, accountEmail);
            ResultSet resultSet = statement.executeQuery(accountExistsStatement);
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    //adding all the data to the database. transactions are made by the users and are added to the database.
    public static void addTransactionToDatabase(Transaction transaction) {
        try {
            Statement statement = connection.createStatement();
            String transactionToDb = String.format(
                    "INSERT INTO Trnsaction VALUES('%s', '%f', '%s', '%s', '%s', '%d');",
                    Database.loggedInAccount,
                    transaction.getAmount(),
                    transaction.getDate(),
                    transaction.getDescription(),
                    transaction.getSign(),
                    transaction.getId()
            );
            statement.executeUpdate(transactionToDb);
        } catch (SQLException e) { //catches any exception being made
            e.printStackTrace();
        }
    }

    //selects all from the database
    public static int getTransactionCount() {
        try {
            Statement statement = connection.createStatement();
            String s = "SELECT COUNT(*) FROM Trnsaction;";
            var rs = statement.executeQuery(s);
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    //gets all the transactions being made for a user in the database and shows it in an array.
    public static ArrayList<Transaction> getAllTransactionsForAccount() {
        ArrayList<Transaction> transactions = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            String s = String.format("SELECT * FROM Trnsaction WHERE accountName = '%s';", Database.loggedInAccount);
            var rs = statement.executeQuery(s);

            while(rs.next()) {
                String aName = rs.getString(1);
                double amount = rs.getDouble(2);
                LocalDate date = rs.getDate(3).toLocalDate();
                String desc = rs.getString(4);
                String sign = rs.getString(5);
                int id = rs.getInt(6);

                if(sign.equals("P")) {
                    transactions.add(new Income(amount, desc, date, id, aName));
                }
                else {
                    transactions.add(new Expense(amount, desc, date, id, aName));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return transactions;
    }


}


