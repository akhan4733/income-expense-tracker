package org.khan.signin;

import javax.swing.*;

//frame being used for the panel
public class SignInFrame extends JFrame {
    private SignUpPanel signInPanel;
    public SignInFrame() {
        signInPanel = new SignUpPanel();
        add(signInPanel);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Sign up Frame");
    }
}