package org.khan.login;

import javax.swing.*;

 //frame being used for the panel
public class LoginFrame extends JFrame {

    private LoginPanel loginPanel;
    public LoginFrame() {
        loginPanel = new LoginPanel();
        add(loginPanel);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Login Frame");
    }
}

