package org.khan.util;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class util {

    // database variables
    private static final String DBURL = "jdbc:mysql://localhost:3306/incomeproject";
    private static final String USER = "root";
    private static final String PASSWORD = "Aamnakhan786";

    private static final String hashPassword = "hashPassword";


    // Email format
    private static final String EMAIL_REGEX = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
    private static final String NAME_REGEX = "\"[a-zA-Z]+\"";

    public static Connection getDatabaseConnection() {
        try {
            return DriverManager.getConnection(DBURL, USER, PASSWORD);
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return null;
    }


    public static String hashPassword(final String base) {
        try{
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            final byte[] hash = digest.digest(base.getBytes("UTF-8"));
            final StringBuilder hexString = new StringBuilder();
            for (int i = 0; i < hash.length; i++) {
                final String hex = Integer.toHexString(0xff & hash[i]);
                if(hex.length() == 1)
                    hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }


    public static boolean isValidEmail(String emailAddrToValidate) {
        return Pattern.matches(EMAIL_REGEX, emailAddrToValidate);
    }


    public static boolean isValidName(String name) {
        // return Pattern.matches(NAME_REGEX, name);
        return name.matches(NAME_REGEX);
    }

    public static boolean emptyField(String field) {
        if(field.strip().isBlank())
            return true;
        return false;
    }

    public static void clearTextField(String field)
    {
        field = "";
    }
}

