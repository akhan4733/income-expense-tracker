package org.khan.login;
import javax.swing.*;

@Deprecated
public class Gui extends JFrame {

    private static final long serialVersionUID = 1L;
    private static final int CELL_SIZE = 100;
    private static final int GRID_WIDTH = 8;
    private static final int GRID_WIDTH_HALF = GRID_WIDTH / 2;
    private static final int WIDTH_OFFSET = 200;

    private static final int CELL_PADDING = CELL_SIZE / 6;
    private static final int SYMBOL_STROKE_WIDTH = 2;

    private int CANVAS_WIDTH;
    private int CANVAS_HEIGHT;


}

