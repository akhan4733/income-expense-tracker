package org.khan.bank;

import java.time.LocalDate;

//showing all the variables used that extend to the transaction class
public class Income extends Transaction {

    //declaring the constants and constraints being defined.
    public Income(double amount, String description, LocalDate date, String aName) {
        super(amount, description, date, 'P', aName);
    }
    public Income(double amount, String description, LocalDate date, int id, String aName) {
        super(amount, description, date, 'P', id, aName);
    }
}


