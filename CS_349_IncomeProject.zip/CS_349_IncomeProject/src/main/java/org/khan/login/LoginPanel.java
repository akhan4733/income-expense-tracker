package org.khan.login;

import org.khan.database.Database;
import org.khan.incomegui.IncomeFrame;
import org.khan.signin.SignInFrame;

import javax.swing.*;
import java.awt.*;


public class LoginPanel extends JPanel{
    private final JTextField usernameTextField = new JTextField(); // username variable being defined as a text field
    private final JPasswordField passTextField = new JPasswordField(); //password variable being defined as a text field
    private final JTextField emailTextField = new JTextField(); //email variable being defined as a text field

    private JButton loginButton; //button for login
    private JButton signUpButton; //button for sign in
    private JLabel userLabel; //label for user
    private JLabel passwordLabel; //password label
    private JLabel emailLabel; //email label
    private JLabel incorrectLabel; //incorrect label

    LoginPanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(96,57,28)); //set color
        setPreferredSize(new Dimension(500,550)); //set size
        setMaximumSize(new Dimension(500, 550)); //set size

        setUpTextFields();
        setUpButtons();
        setUpLabels();

        add(Box.createRigidArea(new Dimension(0,40)));
        add(userLabel);
        add(Box.createRigidArea(new Dimension(0,10)));
        add(usernameTextField);

        add(Box.createRigidArea(new Dimension(0,10)));
        add(passwordLabel);
        add(Box.createRigidArea(new Dimension(0,10)));
        add(passTextField);

        add(Box.createRigidArea(new Dimension(0,10)));
        add(emailLabel);
        add(Box.createRigidArea(new Dimension(0,10)));
        add(emailTextField);

        add(Box.createRigidArea(new Dimension(0,40)));
        add(loginButton);

        add(Box.createRigidArea(new Dimension(0,10)));
        add(signUpButton);

        add(Box.createRigidArea(new Dimension(0,10)));
        add(incorrectLabel);

    }

    //setting the text fields created
    private void setUpTextFields() {
        usernameTextField.setMaximumSize(new Dimension(200,50));
        usernameTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        passTextField.setMaximumSize(new Dimension(200,50));
        passTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        emailTextField.setMaximumSize(new Dimension(200,50));
        emailTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    //creating the buttons
    private void setUpButtons() {
        //login button
        loginButton = new JButton("Login");
        loginButton.setBorderPainted(false);
        loginButton.setOpaque(true);
        loginButton.setFocusPainted(false);
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.addActionListener(e -> {
            if(Database.checkIfAccountExists(
                    emailTextField.getText(), usernameTextField.getText(), new String(passTextField.getPassword()))) {
                Database.loggedInAccount = usernameTextField.getText();
                new IncomeFrame().setVisible(true);
                SwingUtilities.getWindowAncestor(this).dispose();
            }
        });
        //SIGN UP BUTTON
        signUpButton = new JButton("sign up ");
        signUpButton.setBorderPainted(false);
        signUpButton.setOpaque(true);
        signUpButton.setFocusPainted(false);
        signUpButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        signUpButton.addActionListener(e -> {
            new SignInFrame().setVisible(true);
            SwingUtilities.getWindowAncestor(this).dispose();
        });
    }
//setting up the labels
    private void setUpLabels() {
        userLabel = new JLabel("name");
        userLabel.setAlignmentX(CENTER_ALIGNMENT);
        userLabel.setForeground(Color.WHITE);


        passwordLabel = new JLabel("password");
        passwordLabel.setAlignmentX(CENTER_ALIGNMENT);
        passwordLabel.setForeground(Color.WHITE);

        emailLabel = new JLabel("email");
        emailLabel.setAlignmentX(CENTER_ALIGNMENT);
        emailLabel.setForeground(Color.WHITE);

       incorrectLabel = new JLabel("try again, no user found.");
       incorrectLabel.setAlignmentX(CENTER_ALIGNMENT);
       incorrectLabel.setForeground(Color.WHITE);

        incorrectLabel = new JLabel();
        incorrectLabel.setForeground(Color.RED);
        incorrectLabel.setAlignmentX(CENTER_ALIGNMENT);
    }

}

