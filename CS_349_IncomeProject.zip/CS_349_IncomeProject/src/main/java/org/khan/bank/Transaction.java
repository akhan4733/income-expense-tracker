package org.khan.bank;

import org.khan.database.Database;

import java.time.LocalDate;

//abstract class defining the important variables
public abstract class Transaction {
    private double amount; //amount is being used as a double
    private String description; //string used for writing a description
    private LocalDate date; //using "LocalDate" to show the correct format for the date

    private char sign;

    private int id;

    private String aName;

    //declaring the variables
    public Transaction(double amount, String description, LocalDate date, char sign, int id, String aName) {
        this.amount = amount;
        this.description = description;
        this.date = date;
        this.sign = sign;
        this.id = id;
        this.aName = aName;
    }

    //getting these variables and setting it to the database.
    public Transaction(double amount, String description, LocalDate date, char sign, String aName) {
        this.amount = amount;
        this.description = description;
        this.date = date;
        this.sign = sign;
        this.id = Database.getTransactionCount() + 1;
        this.aName = aName;
    }


    //getting and returning all the inputs the user makes and puts in the table.
    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDate() {
        return date;
    }

    public char getSign() {
        return sign;
    }

    public int getId() {
        return id;
    }
}
