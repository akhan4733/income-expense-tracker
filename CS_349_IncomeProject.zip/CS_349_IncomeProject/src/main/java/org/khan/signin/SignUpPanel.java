package org.khan.signin;

import org.khan.database.Database;
import org.khan.login.LoginFrame;

import javax.swing.*;
import java.awt.*;


public class SignUpPanel extends JPanel {
    private final JTextField usernameTextField = new JTextField(); //setting username text field
    private final JPasswordField passTextField = new JPasswordField(); //setting password text field
    private final JTextField emailTextField = new JTextField(); //setting email text field


    private JButton signUpButton; // sign up button
    private JLabel userLabel; //user label
    private JLabel passwordLabel; //password label
    private JLabel emailLabel; //email label

    SignUpPanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(96,57,28));
        setPreferredSize(new Dimension(800,600)); //size
        setMaximumSize(new Dimension(800, 600)); //size

        setUpButtons();
        setUpLabels();
        setUpTextFields();

        add(Box.createRigidArea(new Dimension(0,40))); //size
        add(userLabel);
        add(Box.createRigidArea(new Dimension(0,10))); //size
        add(usernameTextField);

        add(Box.createRigidArea(new Dimension(0,10))); //size
        add(passwordLabel);
        add(Box.createRigidArea(new Dimension(0,10))); //size
        add(passTextField);

        add(Box.createRigidArea(new Dimension(0,10))); //size
        add(emailLabel);
        add(Box.createRigidArea(new Dimension(0,10))); //size
        add(emailTextField);



        add(Box.createRigidArea(new Dimension(0,10)));//size
        add(signUpButton);

        add(Box.createRigidArea(new Dimension(0,10)));//size


    }
//setting up the text fields
    private void setUpTextFields() {
        usernameTextField.setMaximumSize(new Dimension(200,50));
        usernameTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        passTextField.setMaximumSize(new Dimension(200,50));
        passTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        emailTextField.setMaximumSize(new Dimension(200,50));
        emailTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
    }


    //setting up buttons
    private void setUpButtons() {
        signUpButton = new JButton("sign up ");
        signUpButton.setBorderPainted(false);
        signUpButton.setOpaque(true);
        signUpButton.setFocusPainted(false);
        signUpButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        signUpButton.addActionListener(e -> {
            Database.addAccountToDatabase(
                    emailTextField.getText(), usernameTextField.getText(), new String(passTextField.getPassword())
            );
            new LoginFrame().setVisible(true);
            SwingUtilities.getWindowAncestor(this).dispose();
        });
    }

    //setting up labels
    private void setUpLabels() {
        userLabel = new JLabel("name");
        userLabel.setAlignmentX(CENTER_ALIGNMENT);
        userLabel.setForeground(Color.WHITE);

        passwordLabel = new JLabel("password");
        passwordLabel.setAlignmentX(CENTER_ALIGNMENT);
        passwordLabel.setForeground(Color.WHITE);

        emailLabel = new JLabel("email");
        emailLabel.setAlignmentX(CENTER_ALIGNMENT);
        emailLabel.setForeground(Color.WHITE);
    }

}
