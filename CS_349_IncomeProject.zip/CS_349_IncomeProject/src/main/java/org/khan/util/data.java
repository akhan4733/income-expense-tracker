package org.khan.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class data {

    public static int delete(Object obj, String table, String idColumn, int id) {
        Connection conn = null;
        PreparedStatement sqlStatement;

        try {
            conn = util.getDatabaseConnection();

            String query = "DELETE FROM " +table+" WHERE "+ idColumn+" = ?";
            sqlStatement = conn.prepareStatement(query);

            sqlStatement.setInt(1, id);
            return sqlStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
}