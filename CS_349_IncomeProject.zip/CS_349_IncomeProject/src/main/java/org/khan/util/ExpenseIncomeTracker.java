package org.khan;

import org.khan.database.Database;
import org.khan.login.LoginFrame;

import javax.swing.*;

public class ExpenseIncomeTracker {

    public static void main(String[] args) { //main


        Database.startDatabase(); //starting database

        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true)); //if all goes well then start program

    }
}
